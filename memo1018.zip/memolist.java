package team_p1;

import java.awt.Color;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import team_p1.MemoMain3.MyScrollbarUI;

public class memolist extends JFrame implements ActionListener, MouseListener{
	private final static int TOPICON = 28;
	private final static int PADDING = 1;
	private JFrame frame1;
	private JPanel mainP, topP, memoListMainPanel;
	private JTextField tf_1;
	private JButton searchIcon, plusIcon, closeIcon;
	private FrameOption callOption;
	private boolean state_1, state_2;
	private JScrollPane scroll;
	private GridBagLayout gridBag;
	private  GridBagLayout gridControl;
	private int pX, pY;
	private int count=0;
	private Vector<JPanel> memoList;
	private Color whiteBase = new Color(255, 255, 255);
	private Color yellowColor = new Color(255, 242, 171); 
	private Color greenColor = new Color(203, 241, 196);
	private Color pinkColor = new Color(255, 204, 229);
	private Color blueColor = new Color(205, 233, 255);
	private Color grayColor = new Color(249, 249, 249);
	private Color yellowColorSeleted = new Color(255, 235, 129);
	private Color greenColorSeleted = new Color(175, 236, 164);
	private Color pinkColorSeleted = new Color(255, 187, 221);
	private Color blueColorSeleted = new Color(183, 223, 255);
	private Color grayColorSeleted = new Color(229, 229, 229);
	
	public memolist() {//������
		initialize();
	}
	
	public void initialize() {//�⺻��, �ʱ�ȭ, ����
		callOption = new FrameOption();
		Border blackline = BorderFactory.createLineBorder(Color.black); 
		memoList = new Vector<JPanel>();
		Vector<memolistBean> getBean  = new Vector<memolistBean>();
		MemberMgr mgr = new MemberMgr();
		getBean = mgr.loadMemolist("eungyu");
		System.out.println(getBean.size());
		int tf_1size = 200;
		
		frame1 = new JFrame();//������ ������ �����
		frame1.setSize(250, 500);
		frame1.setLocationRelativeTo(null);
//		setLayout(new BorderLayout());
		frame1.setLayout(null);
		frame1.getContentPane().setLayout(null);
		frame1.setResizable(true);
		frame1.setUndecorated(true);

		
		mainP = new JPanel();
		mainP.setLayout(null);
		mainP.setBounds(0, 0, frame1.getWidth(), frame1.getHeight());
		mainP.setBorder(blackline);
		mainP.setBackground(new Color(255, 255, 255));
		frame1.add(mainP);

		
		topP = new JPanel();
		topP.setLayout(null);
		topP.setBackground(whiteBase);
		topP.setBounds(1, 1, frame1.getWidth() - 2, TOPICON);
		topP.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				pX = e.getX();
				pY = e.getY();
			}
		});
		topP.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				int x = e.getXOnScreen();
				int y = e.getYOnScreen();
				frame1.setLocation(x - pX, y - pY);
			}
		});
		
		plusIcon = new JButton(callOption.changeIcon("plusUnfocus", TOPICON, TOPICON));
		plusIcon.setBounds(PADDING, PADDING, TOPICON, TOPICON);
		plusIcon.addActionListener(this);
		plusIcon.addMouseListener(this);
		callOption.buttonSet(plusIcon);
		
		
		closeIcon = new JButton(callOption.changeIcon("closeUnfocus", TOPICON, TOPICON));
		closeIcon.setBounds(topP.getWidth()-TOPICON, PADDING, TOPICON, TOPICON);
		closeIcon.addActionListener(this);
		closeIcon.addMouseListener(this);
		callOption.buttonSet(closeIcon);
		
		
		topP.add(plusIcon);
		topP.add(closeIcon);
		//������� Top Panel
		
		tf_1 = new JTextField();
		tf_1.setFont(new Font("Vandana", Font.PLAIN, 15));
		tf_1.setHorizontalAlignment(JTextField.CENTER);
		tf_1.setBounds(frame1.getWidth()/2-100, 50, tf_1size, 30);
		tf_1.setBackground(new Color(239,239,239));
		tf_1.setBorder(BorderFactory.createEmptyBorder());
		tf_1.setLayout(null);
		
		searchIcon = new JButton(callOption.changeIcon("searchIcon", 25, 25));
		callOption.buttonSet(searchIcon);
		searchIcon.setBounds(tf_1.getWidth()-30,0,30,30);

		tf_1.add(searchIcon);
		//�ؽ�Ʈ�ʵ� �ְ�
		//������� memoListMainPanel #�����ǳ�
		memoListMainPanel = new JPanel();
		 gridBag = new GridBagLayout();
		 gridControl = new GridBagLayout();
		 scroll = new JScrollPane(memoListMainPanel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,	JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); 
		 JScrollBar sb = scroll.getVerticalScrollBar();
		MyScrollbarUI setUiScroll = new MyScrollbarUI(whiteBase);
		sb.setUI(setUiScroll);
		scroll.setBorder(BorderFactory.createLineBorder(whiteBase));
		 
		 scroll.setBounds(1, 100, frame1.getWidth()-2, frame1.getHeight()-100); 
		 scroll.setBackground(new Color(255, 242, 171));
		 mainP.add(scroll);
		 
		 memoListMainPanel.setBackground(whiteBase);
		 memoListMainPanel.setLayout(gridBag);
		
		 
		mainP.add(topP);
		mainP.add(tf_1);
		

		frame1.setVisible(true);
	}


	public void create_form(Component cmpt, int x, int y, int w, int h){

		  GridBagConstraints gbc = new GridBagConstraints();
			//����� �ӽ� �׽�Ʈ �����Դϴ�
		  	gbc.anchor = GridBagConstraints.NORTH;
			gbc.fill = GridBagConstraints.BOTH;
			  gbc.gridx = x;
			  gbc.gridy = y;
			  gbc.gridwidth = w;
			  gbc.gridheight = h;
			  gridBag.setConstraints(cmpt, gbc);
			  memoListMainPanel.add(cmpt);
			  memoListMainPanel.updateUI();
//			temp
//			tempPanel.setBackground(blueColor);

			
			 //������� �׽�Ʈ ���� �Դϴ�.
//			tempPanel.setSize(frame1., height);
//			memoList.add(e)
		}

	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					memolist window = new memolist();
					window.frame1.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if(obj==plusIcon) {
			new MemoMain3(1);		//����Ʈ ��� �޸��� �ӽ� ���		       
		}
		else if(obj==closeIcon) {
			frame1.dispose();
		}
			
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}
	
	@Override
	public void mousePressed(MouseEvent e) {
		Object obj = e.getSource();
		
		if(obj==plusIcon) {
			state_1 = true;
			callOption.buttonChange(plusIcon, "plusClick", TOPICON);
		}
		else if(obj==closeIcon) {
			state_2 = true;
			callOption.buttonChange(closeIcon, "closeClick", TOPICON);
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		Object obj = e.getSource();
		if(obj==plusIcon) {
			state_1 = false;
			callOption.buttonChange(plusIcon, "plusUnfocus", TOPICON);
		}	
		else if(obj==closeIcon) {
			state_2 = false;
			callOption.buttonChange(closeIcon, "closeUnfocus", TOPICON);
		}
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		Object obj = e.getSource();
		if(obj==plusIcon) {
		if (state_1 == false)
			callOption.buttonChange(plusIcon, "plusFocus", TOPICON);
		else if (state_1 == true)
			callOption.buttonChange(plusIcon, "plusClick", TOPICON);
		}
		else if(obj==closeIcon) {
			if (state_2 == false)
				callOption.buttonChange(closeIcon, "closeFocus", TOPICON);
			else if (state_2 == true)
				callOption.buttonChange(closeIcon, "closeClick", TOPICON);
		}
	}
	

	@Override
	public void mouseExited(MouseEvent e) {

		Object obj = e.getSource();

		if(obj==plusIcon) {
			callOption.buttonChange(plusIcon, "plusUnfocus", TOPICON);
		}
		if(obj==closeIcon) {
			callOption.buttonChange(closeIcon, "closeUnfocus", TOPICON);
		}
	}
}
