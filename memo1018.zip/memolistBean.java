package team_p1;
// �޸� ����Ʈ�� ��
public class memolistBean {

	private int memoidx;
	private String contents;
	private String color;
	private String userid;
	
	public int getMemoidx() {
		return memoidx;
	}
	public void setMemoidx(int memoidx) {
		this.memoidx = memoidx;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}

}
