package team_p1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;



public class MemberMgr {
	DBConnectionMgr pool;
	MemberMgr(){
			pool = DBConnectionMgr.getInstance();
	}
	
	public Vector<memolistBean> loadMemolist(String userId){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector <memolistBean> mlist = new Vector<memolistBean>();
		try {
			con = pool.getConnection();
			sql = "select contents, color from memolist where userid = ' "+userId+"'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				memolistBean bean = new memolistBean();
				bean.setContents(rs.getString(1));
				bean.setColor(rs.getString(2));
				mlist.add(bean);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}finally {
			pool.freeConnection(con, pstmt, rs);
		}return mlist;
		
	}
	//List
//	public Vector<MemberBean> listMember() {
//		Connection con = null;
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		String sql = null;
//		Vector <MemberBean> vlist = new Vector<MemberBean>();
//		
//		try {
//			//pool 에서 Connection 빌려옴
//			con = pool.getConnection();
//			sql = "select * from tblMember";
//			pstmt = con.prepareStatement(sql);
//			rs = pstmt.executeQuery();
//			while(rs.next()) {
//				MemberBean bean = new MemberBean();		// bean 객체 생성(idx, name, phone, team Getter and Setter)
//				rs.getInt(1);					//숫자 : idx 순서대로 count해서 반환  문자 1 : idx의 데이터가 1인 데이터들을 반환
//				bean.setMemoidx(rs.getInt(1));									//rs에 있는 첫번째 row의 첫 칸에 있는 데이터를 bean의 idx에 set				
//				bean.setContents(rs.getString(2));						//rs에 있는 첫번째 row의 두번째 칸에있는 String 타입 이름을 bean에 name에 set
//				bean.setColor(rs.getString(3));						//rs에 있는 첫번째 row의 세번째 칸에있는 String 타입 번호를 bean에 name에 set
//				bean.setUserid(rs.getString(4));							//rs에 있는 첫번째 row의 네번째 칸에있는 String 타입 팀명을 bean에 name에 set
//				vlist.addElement(bean);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			pool.freeConnection(con, pstmt, rs);					// null로 전부 반환해줌
//		}
//		return vlist;
//	}
//	//Read(레코드 1개 select)
//	public MemberBean getMember(int idx) {
//		Connection con = null;
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		String sql = null;
//		MemberBean bean = new MemberBean();
//		try {
//			con = pool.getConnection();
//			sql = "select * from tblMember where idx=?";
//			pstmt = con.prepareStatement(sql);
//			pstmt.setInt(1, idx);
//			rs = pstmt.executeQuery();
//			//idx 가 primary key 이기 때문에 절대 2개 이상의 값은 올 수 없다.
//			if(rs.next()) {
//				bean.setMemoidx(rs.getInt(1));
//				bean.setContents(rs.getString(2));
//				bean.setColor(rs.getString(3));
//				bean.setUserid(rs.getString(4));
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			pool.freeConnection(con, pstmt, rs);
//		}
//		return bean;
//	}

	//Insert
//	public boolean insertMember(MemberBean bean) {
//		Connection con = null;
//		PreparedStatement pstmt = null;
//		String sql = null;
//		boolean flag = false;
//		try {
//			con = pool.getConnection();
//			sql = "insert into tblMember(name, phone, team)" + "values(?,?,?)";
//			pstmt = con.prepareStatement(sql);
//			pstmt.setString(1, bean.getName());
//			pstmt.setString(2, bean.getPhone());
//			pstmt.setString(3, bean.getTeam());
//			int cnt = pstmt.executeUpdate();
//			if(cnt==1)
//				flag = true;
//			System.out.println(flag);
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			pool.freeConnection(con, pstmt);
//		}
//		return flag;		//flag : 제어권
//	}
	//Update
	//update tblMember set name=?, phone=?,team=?
//	public boolean updateMember(MemberBean bean) {
//		Connection con = null;
//		PreparedStatement pstmt = null;
//		String sql = null;
//		boolean flag = false;
//		try {
//			con = pool.getConnection();
//			sql = "update tblMember set name=?, phone=?, team=? where idx=?";
//			pstmt = con.prepareStatement(sql);
//			pstmt.setString(1, bean.getName());
//			pstmt.setString(2, bean.getPhone());
//			pstmt.setString(3, bean.getTeam());
//			pstmt.setInt(4, bean.getIdx());
//			int cnt = pstmt.executeUpdate();
//			if(cnt==1)
//				flag = true;
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			pool.freeConnection(con, pstmt);
//		}
//		return flag;
//	}
	//Delete
//	public boolean deleteMember(int idx) {
//		Connection con = null;
//		PreparedStatement pstmt = null;
//		String sql = null;
//		boolean flag = false;
//		try {
//			con = pool.getConnection();
//			sql = "delete from tblMember where idx=?";
//			pstmt = con.prepareStatement(sql);
//			pstmt.setInt(1, idx);
//			if(pstmt.executeUpdate()==1)		//정상접속경우
//				flag=true;
//			System.out.println(flag);
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			pool.freeConnection(con, pstmt);
//		}
//		return flag;
//	}
}

